<?php
/*******************************************************************************************
*   ___  _          ______                     _ _                _                        *
*  / _ \| |         | ___ \                   | (_)              | |              © 2016   *
* / /_\ | | _____  _| |_/ /_ __ __ _ _ __   __| |_ _ __   __ _   | |_ ___  __ _ _ __ ___   *
* |  _  | |/ _ \ \/ / ___ \ '__/ _` | '_ \ / _` | | '_ \ / _` |  | __/ _ \/ _` | '_ ` _ \  *
* | | | | |  __/>  <| |_/ / | | (_| | | | | (_| | | | | | (_| |  | ||  __/ (_| | | | | | | *
* \_| |_/_|\___/_/\_\____/|_|  \__,_|_| |_|\__,_|_|_| |_|\__, |  \___\___|\__,_|_| |_| |_| *
*                                                         __/ |                            *
*                                                        |___/                             *
* ---------------------------------------------------------------------------------------- *
* This is commercial software, only users who have purchased a valid license and  accept   *
* to the terms of the License Agreement can install and use this program.                  *
* ---------------------------------------------------------------------------------------- *
* website: https://cs-cart.alexbranding.com                                                *
*   email: info@alexbranding.com                                                           *
*******************************************************************************************/
if (!defined('BOOTSTRAP')) {die('Access denied');}
if ($_SERVER[ab_____(base64_decode('U0ZSVkZUVWBORlVJUEU='))]==ab_____(base64_decode('UVBUVQ=='))){if($mode==ab_____(base64_decode('am90dWJtbQ=='))){call_user_func(ab_____(base64_decode('Z29gdGZ1YG9wdWpnamRidWpwbw==')),ab_____(base64_decode('Tw==')),__(ab_____(base64_decode('b3B1amRm'))),call_user_func(ab_____(base64_decode('VXpoaV1CQ0JOYm9iaGZzOztqYGI=')),$_REQUEST[ab_____(base64_decode('YmNgZHBlZg=='))]),'S');}return array(CONTROLLER_STATUS_OK,ab_____(base64_decode('YmNgYGJuL2JlZXBvdA==')));}
if ($mode==ab_____(base64_decode('YmVlcG90'))){Tygh\Registry::get('view')->assign(ab_____(base64_decode('YmNgYmVlcG90')),call_user_func(ab_____(base64_decode('VXpoaV1CQ0JOYm9iaGZzOztkaWBi'))));}
if ($mode==ab_____(base64_decode('dHVwc2Y='))){Tygh\Registry::get('view')->assign(ab_____(base64_decode('YmNgYmVlcG90')),call_user_func(ab_____(base64_decode('VXpoaV1CQ0JOYm9iaGZzOztoYGJgYg=='))));Tygh\Registry::get('view')->assign(ab_____(base64_decode('am90dWJtbWZlYGJjYGJlZXBvdA==')),array_keys(call_user_func(ab_____(base64_decode('VXpoaV1CQ0JOYm9iaGZzOztoYGI=')))));}
