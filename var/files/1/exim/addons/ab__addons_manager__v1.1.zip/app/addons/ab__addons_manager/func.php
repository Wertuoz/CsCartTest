<?php
/*******************************************************************************************
*   ___  _          ______                     _ _                _                        *
*  / _ \| |         | ___ \                   | (_)              | |              © 2016   *
* / /_\ | | _____  _| |_/ /_ __ __ _ _ __   __| |_ _ __   __ _   | |_ ___  __ _ _ __ ___   *
* |  _  | |/ _ \ \/ / ___ \ '__/ _` | '_ \ / _` | | '_ \ / _` |  | __/ _ \/ _` | '_ ` _ \  *
* | | | | |  __/>  <| |_/ / | | (_| | | | | (_| | | | | | (_| |  | ||  __/ (_| | | | | | | *
* \_| |_/_|\___/_/\_\____/|_|  \__,_|_| |_|\__,_|_|_| |_|\__, |  \___\___|\__,_|_| |_| |_| *
*                                                         __/ |                            *
*                                                        |___/                             *
* ---------------------------------------------------------------------------------------- *
* This is commercial software, only users who have purchased a valid license and  accept   *
* to the terms of the License Agreement can install and use this program.                  *
* ---------------------------------------------------------------------------------------- *
* website: https://cs-cart.alexbranding.com                                                *
*   email: info@alexbranding.com                                                           *
*******************************************************************************************/
if (!defined('BOOTSTRAP')) { die('Access denied'); }
function ab_____($_){$__='';for($____=0;$____<strlen($_);$____++){$___=ord($_[$____]);$__.=chr(--$___);}return $__;}
if (AREA == 'A') call_user_func(ab_____(base64_decode('VXpoaV1TZmhqdHVzejs7c2ZoanR1ZnNEYmRpZg==')),ab_____(base64_decode('dGZ1dWpvaHRgYmNibg==')), ab_____(base64_decode('OTc1MTE=')), call_user_func(ab_____(base64_decode('VXpoaV1TZmhqdHVzejs7ZGJkaWZNZndmbQ==')),ab_____(base64_decode('dWpuZg=='))));
