<?php

$schema['ab__am'] = array(
    'modes' => array(
        'addons' => array (
            'permissions' => 'ab__am.manage',
        ),
        'store' => array (
            'permissions' => 'ab__am.manage',
        ),
        'install' => array (
            'permissions' => 'ab__am.manage',
        ),
    ),
);

return $schema;
