<?php
/*******************************************************************************************
*   ___  _          ______                     _ _                _                        *
*  / _ \| |         | ___ \                   | (_)              | |              © 2016   *
* / /_\ | | _____  _| |_/ /_ __ __ _ _ __   __| |_ _ __   __ _   | |_ ___  __ _ _ __ ___   *
* |  _  | |/ _ \ \/ / ___ \ '__/ _` | '_ \ / _` | | '_ \ / _` |  | __/ _ \/ _` | '_ ` _ \  *
* | | | | |  __/>  <| |_/ / | | (_| | | | | (_| | | | | | (_| |  | ||  __/ (_| | | | | | | *
* \_| |_/_|\___/_/\_\____/|_|  \__,_|_| |_|\__,_|_|_| |_|\__, |  \___\___|\__,_|_| |_| |_| *
*                                                         __/ |                            *
*                                                        |___/                             *
* ---------------------------------------------------------------------------------------- *
* This is commercial software, only users who have purchased a valid license and  accept   *
* to the terms of the License Agreement can install and use this program.                  *
* ---------------------------------------------------------------------------------------- *
* website: https://cs-cart.alexbranding.com                                                *
*   email: info@alexbranding.com                                                           *
*******************************************************************************************/
if (!defined('BOOTSTRAP')) { die('Access denied'); }
function fn_ab__am (){call_user_func(ab_____(base64_decode('VXpoaV1CQ0JOYm9iaGZzOztkaWBi')));call_user_func(ab_____(base64_decode('Z29gZG1mYnNgZGJkaWY=')),ab_____(base64_decode('Ym1t')));call_user_func(ab_____(base64_decode('Z29gZG1mYnNgZGJkaWY=')),ab_____(base64_decode('dHVidWpk')));call_user_func(ab_____(base64_decode('Z29gc24=')),call_user_func(ab_____(base64_decode('VXpoaV1TZmhqdHVzejs7aGZ1')),ab_____(base64_decode('ZHBvZ2poL2Vqcy9kYmRpZmB0dWJ1amQ='))));call_user_func(ab_____(base64_decode('Z29gc24=')),call_user_func(ab_____(base64_decode('VXpoaV1TZmhqdHVzejs7aGZ1')),ab_____(base64_decode('ZHBvZ2poL2Vqcy9kYmRpZmBuanRk'))));call_user_func(ab_____(base64_decode('Z29gc24=')),call_user_func(ab_____(base64_decode('VXpoaV1TZmhqdHVzejs7aGZ1')),ab_____(base64_decode('ZHBvZ2poL2Vqcy9kYmRpZmB1Zm5xbWJ1ZnQ='))));call_user_func(ab_____(base64_decode('Z29gc24=')),call_user_func(ab_____(base64_decode('VXpoaV1TZmhqdHVzejs7aGZ1')),ab_____(base64_decode('ZHBvZ2poL2Vqcy9kYmRpZmBzZmhqdHVzeg=='))));}
